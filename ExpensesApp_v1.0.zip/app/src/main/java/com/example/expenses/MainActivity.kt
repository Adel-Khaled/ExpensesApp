package com.example.expenses

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.expenses.data.Expense
import com.example.expenses.ui.theme.ExpensesTheme
import java.io.File
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

private val categories = listOf("Home", "Food", "Transportation", "Shopping", "Bills", "Health", "Entertainment", "Communication", "Other")
private val blue = Color(0xFF1976F3)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { ExpensesApp() } }
}

@Composable fun ExpensesApp(vm: MainViewModel = viewModel()) {
    var dark by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(0) }
    var screen by remember { mutableStateOf<String?>(null) }
    var selectedId by remember { mutableStateOf<Long?>(null) }
    ExpensesTheme(dark) {
        when (screen) {
            "add" -> ExpenseEditor(vm, null, onBack = { screen = null })
            "detail" -> selectedId?.let { ExpenseDetail(vm, it, onBack = { screen = null }, onEdit = { screen = "edit" }, onDeleted = { screen = null }) }
            "edit" -> selectedId?.let { EditLoader(vm, it, onBack = { screen = "detail" }, onSaved = { screen = "detail" }) }
            else -> MainShell(vm, tab, { tab = it }, { screen = "add" }, { selectedId = it; screen = "detail" }, dark, { dark = it })
        }
    }
}

@Composable private fun MainShell(vm: MainViewModel, tab: Int, onTab: (Int) -> Unit, add: () -> Unit, open: (Long) -> Unit, dark: Boolean, setDark: (Boolean) -> Unit) {
    Scaffold(
        bottomBar = { NavigationBar { listOf("Home" to Icons.Default.Home, "Summary" to Icons.Default.Assessment, "Search" to Icons.Default.Search, "Settings" to Icons.Default.Settings).forEachIndexed { i, pair -> NavigationBarItem(selected = tab == i, onClick = { onTab(i) }, icon = { Icon(pair.second, null) }, label = { Text(pair.first) }) } } },
        floatingActionButton = { if (tab == 0) FloatingActionButton(onClick = add, containerColor = blue, contentColor = Color.White) { Icon(Icons.Default.Add, "Add Expense") } }
    ) { p -> Box(Modifier.padding(p).fillMaxSize()) {
        when(tab) {
            0 -> HomeScreen(vm.expenses.collectAsState().value, open)
            1 -> SummaryScreen(vm.expenses.collectAsState().value)
            2 -> SearchScreen(vm.expenses.collectAsState().value, open)
            else -> SettingsScreen(dark, setDark)
        }
    }}
}

@Composable private fun HomeScreen(all: List<Expense>, open: (Long) -> Unit) {
    var month by remember { mutableStateOf(Calendar.getInstance().let { it.set(Calendar.DAY_OF_MONTH, 1); it.timeInMillis }) }
    val monthExpenses = remember(all, month) { all.filter { sameMonth(it.dateTime, month) } }
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(18.dp)); Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) { Text("Expenses", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Icon(Icons.Default.Search, null); Spacer(Modifier.width(18.dp)); Icon(Icons.Default.Settings, null) }
        MonthSelector(month) { month = addMonth(month, it) }
        SummaryCard(monthExpenses)
        Row(Modifier.padding(top = 18.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) { Text("Recent Expenses", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Text("${monthExpenses.size} items", color = blue, fontSize = 13.sp) }
        if (monthExpenses.isEmpty()) EmptyState()
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 90.dp)) { items(monthExpenses, key = { it.id }) { ExpenseCard(it, open) } }
    }
}

@Composable private fun MonthSelector(month: Long, change: (Int) -> Unit) { Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) { IconButton({ change(-1) }) { Icon(Icons.Default.ChevronLeft, "Previous month") }; Text(formatMonth(month), fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 22.dp)); IconButton({ change(1) }) { Icon(Icons.Default.ChevronRight, "Next month") } } }

@Composable private fun SummaryCard(list: List<Expense>) { val total = list.sumOf { it.amount }; val largest = list.maxOfOrNull { it.amount } ?: 0.0; Card(colors = CardDefaults.cardColors(containerColor = blue), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp)) { Text("Total This Month", color = Color.White.copy(.8f)); Text(money(total), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(16.dp)); Row { Text("${list.size}\nExpenses", color = Color.White, modifier = Modifier.weight(1f)); Text("Largest\n${money(largest)}", color = Color.White, modifier = Modifier.weight(1f)) } } } }

@Composable private fun ExpenseCard(e: Expense, open: (Long) -> Unit) { Card(Modifier.fillMaxWidth().clickable { open(e.id) }, shape = RoundedCornerShape(16.dp)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(44.dp).clip(CircleShape).background(categoryColor(e.category).copy(alpha=.14f)), contentAlignment = Alignment.Center) { Icon(categoryIcon(e.category), null, tint = categoryColor(e.category)) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(e.name, fontWeight = FontWeight.SemiBold); Text(e.category, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(formatDateTime(e.dateTime), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Text(money(e.amount), fontWeight = FontWeight.Bold); } } }

@Composable private fun EmptyState() { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(bottom = 70.dp)) { Icon(Icons.Default.ReceiptLong, null, modifier = Modifier.size(70.dp), tint = blue.copy(.35f)); Spacer(Modifier.height(12.dp)); Text("No expenses yet", fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("Start tracking your spending by adding your first expense.", color = MaterialTheme.colorScheme.onSurfaceVariant); } } }

@Composable private fun ExpenseEditor(vm: MainViewModel, existing: Expense?, onBack: () -> Unit) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(existing?.name ?: "") }; var amount by remember { mutableStateOf(existing?.amount?.toString() ?: "") }; var category by remember { mutableStateOf(existing?.category ?: "Other") }; var date by remember { mutableStateOf(existing?.dateTime ?: System.currentTimeMillis()) }; var image by remember { mutableStateOf(existing?.imageUri) }; var showCategory by remember { mutableStateOf(false) }; var showPhoto by remember { mutableStateOf(false) }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? -> uri?.let { image = it.toString() } }
    val cameraFile = remember { File(context.cacheDir, "images/${UUID.randomUUID()}.jpg").also { it.parentFile?.mkdirs() } }
    val cameraUri = remember(cameraFile) { FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", cameraFile) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok -> if (ok) image = cameraUri.toString() }
    Scaffold(topBar = { TopAppBar(title = { Text(if (existing == null) "Add Expense" else "Edit Expense") }, navigationIcon = { IconButton(onBack) { Icon(Icons.Default.ArrowBack, null) } }) }) { p -> Column(Modifier.padding(p).padding(horizontal = 18.dp).verticalScroll(androidx.compose.foundation.rememberScrollState())) {
        LabeledField("Expense Name", name, "Enter expense name") { name = it }; LabeledField("Amount (EGP)", amount, "0.00", true) { amount = it }
        Text("Category (Optional)", fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp)); OutlinedButton({ showCategory = true }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) { Icon(Icons.Default.Category, null); Spacer(Modifier.width(8.dp)); Text(category); Spacer(Modifier.weight(1f)); Icon(Icons.Default.KeyboardArrowDown, null) }
        Text("Date & Time", fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp)); OutlinedButton({ val cal = Calendar.getInstance().apply { timeInMillis = date }; DatePickerDialog(context, { _, y, m, d -> val c = Calendar.getInstance().apply { timeInMillis = date; set(Calendar.YEAR, y); set(Calendar.MONTH, m); set(Calendar.DAY_OF_MONTH, d) }; TimePickerDialog(context, { _, h, min -> c.set(Calendar.HOUR_OF_DAY, h); c.set(Calendar.MINUTE, min); date = c.timeInMillis }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false).show() }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show() }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) { Icon(Icons.Default.CalendarToday, null); Spacer(Modifier.width(8.dp)); Text(formatDateTime(date)) }
        Text("Photo (Optional)", fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp)); OutlinedButton({ showPhoto = true }, Modifier.fillMaxWidth().height(110.dp), shape = RoundedCornerShape(12.dp)) { if (image == null) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.AddPhotoAlternate, null); Text("Add Photo") } } else AsyncImage(image, null, Modifier.fillMaxSize().padding(4.dp), contentScale = ContentScale.Crop) }
        Spacer(Modifier.height(22.dp)); Button(onClick = { val a = amount.toDoubleOrNull() ?: 0.0; if (name.isNotBlank() && a >= 0) { vm.save(Expense(existing?.id ?: 0, name.trim(), a, category, date, image)); onBack() } }, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp)) { Text(if (existing == null) "Save Expense" else "Save Changes") }; Spacer(Modifier.height(24.dp))
    } }
    if (showCategory) AlertDialog(onDismissRequest = { showCategory = false }, title = { Text("Select Category") }, text = { Column { categories.forEach { Text(it, Modifier.fillMaxWidth().clickable { category = it; showCategory = false }.padding(14.dp)) } } }, confirmButton = {})
    if (showPhoto) AlertDialog(onDismissRequest = { showPhoto = false }, title = { Text("Add Photo") }, text = { Column { ListItem(headlineContent={Text("Take Photo")}, leadingContent={Icon(Icons.Default.CameraAlt,null)}, modifier=Modifier.clickable { showPhoto=false; camera.launch(cameraUri) }); ListItem(headlineContent={Text("Choose from Gallery")}, leadingContent={Icon(Icons.Default.PhotoLibrary,null)}, modifier=Modifier.clickable { showPhoto=false; gallery.launch("image/*") }); ListItem(headlineContent={Text("Cancel")}, leadingContent={Icon(Icons.Default.Close,null)}, modifier=Modifier.clickable { showPhoto=false }) } }, confirmButton = {})
}

@Composable private fun LabeledField(label: String, value: String, placeholder: String, number: Boolean = false, onChange: (String) -> Unit) { Text(label, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp, bottom = 6.dp)); OutlinedTextField(value, onChange, Modifier.fillMaxWidth(), placeholder={Text(placeholder)}, singleLine=true, shape=RoundedCornerShape(12.dp), keyboardOptions=if(number) KeyboardOptions(keyboardType=androidx.compose.ui.text.input.KeyboardType.Decimal) else KeyboardOptions.Default) }

@Composable private fun EditLoader(vm: MainViewModel, id: Long, onBack: () -> Unit, onSaved: () -> Unit) { var expense by remember { mutableStateOf<Expense?>(null) }; LaunchedEffect(id) { expense = vm.get(id) }; expense?.let { ExpenseEditor(vm, it, onBack = onSaved) } ?: Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() } }

@Composable private fun ExpenseDetail(vm: MainViewModel, id: Long, onBack: () -> Unit, onEdit: () -> Unit, onDeleted: () -> Unit) { var e by remember { mutableStateOf<Expense?>(null) }; var confirm by remember { mutableStateOf(false) }; LaunchedEffect(id) { e = vm.get(id) }; e?.let { expense -> Scaffold(topBar={TopAppBar(title={Text("Expense Details")},navigationIcon={IconButton(onBack){Icon(Icons.Default.ArrowBack,null)}})}) { p -> Column(Modifier.padding(p).padding(18.dp)) { expense.imageUri?.let { AsyncImage(it,null,Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(18.dp)),ContentScale.Crop); Spacer(Modifier.height(14.dp)) }; Text(expense.category, color=blue); Text(expense.name,fontSize=28.sp,fontWeight=FontWeight.Bold); Text(money(expense.amount),fontSize=32.sp,fontWeight=FontWeight.Bold,color=Color(0xFF008A5A),modifier=Modifier.padding(vertical=14.dp)); DetailLine("Date",formatDate(expense.dateTime)); DetailLine("Time",formatTime(expense.dateTime)); Spacer(Modifier.weight(1f)); Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)){Button({onEdit()},Modifier.weight(1f)){Icon(Icons.Default.Edit,null);Spacer(Modifier.width(6.dp));Text("Edit")};Button({confirm=true},Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFFFE5E3),contentColor=Color(0xFFD92D20))){Icon(Icons.Default.Delete,null);Spacer(Modifier.width(6.dp));Text("Delete")}} } } }; if(confirm) AlertDialog(onDismissRequest={confirm=false},title={Text("Delete Expense?")},text={Text("Are you sure you want to delete this expense? This action cannot be undone.")},dismissButton={TextButton({confirm=false}){Text("Cancel")}},confirmButton={Button({vm.delete(e!!);confirm=false;onDeleted()},colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFD92D20))){Text("Delete")}}) }
}
@Composable private fun DetailLine(k:String,v:String){Row(Modifier.fillMaxWidth().padding(vertical=8.dp)){Text(k,color=MaterialTheme.colorScheme.onSurfaceVariant,modifier=Modifier.weight(1f));Text(v,fontWeight=FontWeight.Medium)}}

@Composable private fun SummaryScreen(all: List<Expense>) { var month by remember { mutableStateOf(Calendar.getInstance().let{it.set(Calendar.DAY_OF_MONTH,1);it.timeInMillis}) }; val list=all.filter{sameMonth(it.dateTime,month)}; val total=list.sumOf{it.amount}; val grouped=list.groupBy{it.category}.mapValues{it.value.sumOf{e->e.amount}}.toList().sortedByDescending{it.second}; Column(Modifier.fillMaxSize().padding(18.dp)){ Text("Monthly Summary",fontSize=28.sp,fontWeight=FontWeight.Bold); MonthSelector(month){month=addMonth(month,it)}; Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(18.dp)){Stat("Total Spending",money(total));Stat("Number of Expenses",list.size.toString());Stat("Largest Expense",money(list.maxOfOrNull{it.amount}?:0.0))}}; Text("Spending by Category",fontSize=18.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=22.dp,bottom=10.dp)); LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(grouped){(cat,amt)-> val pct=if(total>0)amt/total else 0.0; Column{Row{Text(cat,modifier=Modifier.weight(1f));Text("${money(amt)}  ${"%.0f".format(Locale.US,pct*100)}%")}; LinearProgressIndicator({pct.toFloat()},Modifier.fillMaxWidth().padding(top=5.dp))}}} } }
@Composable private fun Stat(a:String,b:String){Row(Modifier.fillMaxWidth().padding(vertical=7.dp)){Text(a,modifier=Modifier.weight(1f));Text(b,fontWeight=FontWeight.Bold)}}

@Composable private fun SearchScreen(all: List<Expense>, open:(Long)->Unit){var q by remember{mutableStateOf("")};var cat by remember{mutableStateOf("All")};val list=all.filter{it.name.contains(q,true)&&(cat=="All"||it.category==cat)};Column(Modifier.fillMaxSize().padding(18.dp)){Text("Search",fontSize=28.sp,fontWeight=FontWeight.Bold);OutlinedTextField(q,{q=it},Modifier.fillMaxWidth().padding(top=14.dp),placeholder={Text("Search expenses...")},leadingIcon={Icon(Icons.Default.Search,null)},trailingIcon={if(q.isNotEmpty())IconButton({q=""}){Icon(Icons.Default.Close,null)}else null},singleLine=true,shape=RoundedCornerShape(14.dp));Row(Modifier.fillMaxWidth().padding(vertical=12.dp),horizontalArrangement=Arrangement.spacedBy(7.dp)){listOf("All","Home","Food","Transportation","Shopping").forEach{FilterChip(selected=cat==it,onClick={cat=it},label={Text(it)})}};LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp)){items(list){ExpenseCard(it,open)}}} }

@Composable private fun SettingsScreen(dark:Boolean,setDark:(Boolean)->Unit){Column(Modifier.fillMaxSize().padding(18.dp)){Text("Settings",fontSize=28.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(20.dp));Card(Modifier.fillMaxWidth()){ListItem(headlineContent={Text("Dark Mode")},supportingContent={Text("Use a darker appearance")},trailingContent={Switch(dark,setDark)})};Spacer(Modifier.height(12.dp));Card(Modifier.fillMaxWidth()){ListItem(headlineContent={Text("Currency")},supportingContent={Text("Egyptian Pound (EGP)")})};Spacer(Modifier.height(12.dp));Text("Expenses v1.0",color=MaterialTheme.colorScheme.onSurfaceVariant,modifier=Modifier.padding(top=12.dp))}}

private fun money(v:Double)=NumberFormat.getNumberInstance(Locale.US).apply{minimumFractionDigits=2;maximumFractionDigits=2}.format(v).let{"EGP $it"}
private fun formatMonth(t:Long)=SimpleDateFormat("MMMM yyyy",Locale.US).format(Date(t)); private fun formatDateTime(t:Long)=SimpleDateFormat("MMM d, yyyy • h:mm a",Locale.US).format(Date(t)); private fun formatDate(t:Long)=SimpleDateFormat("MMM d, yyyy",Locale.US).format(Date(t)); private fun formatTime(t:Long)=SimpleDateFormat("h:mm a",Locale.US).format(Date(t))
private fun sameMonth(a:Long,b:Long):Boolean{val x=Calendar.getInstance().apply{timeInMillis=a};val y=Calendar.getInstance().apply{timeInMillis=b};return x.get(Calendar.YEAR)==y.get(Calendar.YEAR)&&x.get(Calendar.MONTH)==y.get(Calendar.MONTH)}
private fun addMonth(t:Long,d:Int)=Calendar.getInstance().apply{timeInMillis=t;add(Calendar.MONTH,d)}.timeInMillis
private fun categoryColor(c:String)=when(c){"Home"->Color(0xFFE74C3C);"Food"->Color(0xFFFF8A00);"Transportation"->Color(0xFF2878E8);"Shopping"->Color(0xFF16A085);"Bills"->Color(0xFFFFB000);"Health"->Color(0xFFE84393);else->blue}
private fun categoryIcon(c:String)=when(c){"Home"->Icons.Default.Home;"Food"->Icons.Default.Restaurant;"Transportation"->Icons.Default.DirectionsCar;"Shopping"->Icons.Default.ShoppingCart;"Bills"->Icons.Default.Bolt;"Health"->Icons.Default.Favorite;"Entertainment"->Icons.Default.Movie;else->Icons.Default.MoreHoriz}
