package com.example.expenses.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF1976F3),
    onPrimary = Color.White,
    secondary = Color(0xFF4F647D),
    background = Color(0xFFF7F9FC),
    surface = Color.White,
    surfaceVariant = Color(0xFFEFF3F8),
    error = Color(0xFFD92D20)
)
private val DarkColors = darkColorScheme(
    primary = Color(0xFF72A8FF),
    background = Color(0xFF10141A),
    surface = Color(0xFF171C23),
    surfaceVariant = Color(0xFF242B35),
    error = Color(0xFFFF8A80)
)

@Composable fun ExpensesTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (darkTheme) DarkColors else LightColors, typography = Typography(), content = content)
}
