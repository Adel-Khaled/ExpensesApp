package com.example.expenses

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.expenses.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = ExpenseRepository(AppDatabase.get(app).expenseDao())
    val expenses: StateFlow<List<Expense>> = repo.all.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun save(expense: Expense) = viewModelScope.launch {
        if (expense.id == 0L) repo.insert(expense) else repo.update(expense)
    }
    fun delete(expense: Expense) = viewModelScope.launch { repo.delete(expense) }
    suspend fun get(id: Long): Expense? = repo.get(id)
}
