package com.example.expenses.data

class ExpenseRepository(private val dao: ExpenseDao) {
    val all = dao.observeAll()
    suspend fun get(id: Long) = dao.getById(id)
    suspend fun insert(e: Expense) = dao.insert(e)
    suspend fun update(e: Expense) = dao.update(e)
    suspend fun delete(e: Expense) = dao.delete(e)
}
